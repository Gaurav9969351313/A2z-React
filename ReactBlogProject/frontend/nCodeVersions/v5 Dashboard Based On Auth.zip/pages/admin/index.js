import Layout from '../../components/Layout';
import Link from 'next/link';
import Admin from '../../components/auth/admin';

export default function AdminIndex() {
    return (
        
            <Layout>
                <Admin>
                    <h3>Admin Dashboard</h3>
                </Admin>
            </Layout>
        
    )
}
