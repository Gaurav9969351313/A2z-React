module.exports = {
    publicRuntimeConfig : {
        APP_NAME: 'Garrys Blog',
        DOMAIN_DEVELOPMENT: 'http://localhost:3003',
        PRODUCTION : false      
    }
}