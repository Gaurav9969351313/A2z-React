import Layout from '../components/Layout';

export default function signin() {
    return (
    <Layout>
        <h3>This Is SignIn page</h3>
    </Layout>
    )
}
