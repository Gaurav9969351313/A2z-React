import Layout from '../components/Layout';
import Link  from 'next/link';


export default function signup() {
    return (
    <Layout>
        <h3>This Is SignUp page</h3>
        <Link href="/">Home </Link>
    </Layout>
    )
}
